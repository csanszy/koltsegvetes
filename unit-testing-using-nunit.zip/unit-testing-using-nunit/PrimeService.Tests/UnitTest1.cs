using NUnit.Framework;
using PrimeServices;

namespace PrimeService.Tests
{
    [TestFixture]
    public class PrimeService_IsPrimeShould
    {
        private PrimeServices.PrimeService _primeService;

        [SetUp]
        public void SetUp()
        {
            _primeService = new PrimeServices.PrimeService();
        }

        [Test]
        public void IsPrime_InputIs1_ReturnFalse()
        {
            var result = _primeService.IsPrime(1);

            Assert.That(result, Is.False, "1 should not be prime");
        }
    }
}